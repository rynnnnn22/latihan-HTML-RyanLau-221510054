<?php
// Database connection details
$host = "localhost";
$user = "root";
$password = "";
$dbname = "form_db";

// Create database connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // If connection fails, terminate and display error
    die("Koneksi gagal: " . $conn->connect_error);
}

// Retrieve data from the POST request and sanitize it
// Using mysqli_real_escape_string to prevent SQL injection vulnerabilities
$nama = $conn->real_escape_string($_POST['nama']);
$email = $conn->real_escape_string($_POST['email']);
$alamat = $conn->real_escape_string($_POST['alamat']); // New: Retrieve 'alamat' field
$pesan = $conn->real_escape_string($_POST['pesan']);

// SQL INSERT statement to add data to the 'kontak' table
// Ensure 'alamat' column is included in the table schema (as updated previously)
$sql = "INSERT INTO kontak (nama, email, alamat, pesan) VALUES ('$nama', '$email', '$alamat', '$pesan')";

// Execute the SQL query
if ($conn->query($sql) === TRUE) {
    // If data is successfully inserted
    echo "Data berhasil dikirim!";
} else {
    // If there's an error during insertion, display the error
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
