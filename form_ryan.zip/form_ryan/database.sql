-- Create the database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS form_db;

-- Switch to using the 'form_db' database
USE form_db;

-- Create the 'kontak' table if it doesn't already exist
-- This table will store contact form submissions.
CREATE TABLE IF NOT EXISTS kontak (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each submission, auto-increments
    nama VARCHAR(100) NOT NULL,        -- Name of the sender (required)
    email VARCHAR(100) NOT NULL,       -- Email of the sender (required)
    alamat VARCHAR(255) NOT NULL,      -- Address of the sender (required, new column)
    pesan TEXT NOT NULL,               -- Message content (required)
    waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of when the record was created
);

-- Optional: Add the 'alamat' column if the table already exists without it.
-- This ALTER TABLE statement ensures the 'alamat' column is present.
-- It sets a default value for existing rows if the column is added.
ALTER TABLE kontak
ADD COLUMN IF NOT EXISTS alamat VARCHAR(255) NOT NULL DEFAULT 'Tidak Ada Alamat';

-- Optional: Insert an example record into the 'kontak' table
-- This is useful for testing the database setup.
INSERT INTO kontak (nama, email, alamat, pesan) VALUES
('Andi', 'andi@example.com', 'Jl. Contoh No. 123', 'Halo, ini pesan pertama.');
